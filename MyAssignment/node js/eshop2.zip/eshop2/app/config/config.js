var config = {
    port: 3000,
    dbconnection: "mongodb://localhost:27017/eShop"
};

module.exports = config;
