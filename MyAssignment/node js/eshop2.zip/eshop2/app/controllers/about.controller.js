var controller = {};
controller.get = function (req, res) {
    res.render("about");
};
module.exports = controller;
