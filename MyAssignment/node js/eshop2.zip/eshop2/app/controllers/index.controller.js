var controller = {};
controller.get = function (req, res) {
  res.render("index");
};
module.exports = controller;
